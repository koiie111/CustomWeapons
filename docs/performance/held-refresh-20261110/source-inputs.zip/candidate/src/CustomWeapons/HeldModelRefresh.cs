using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Utils;
using CustomWeapons.Core;
using Microsoft.Extensions.Logging;

namespace CustomWeapons;

public sealed partial class CustomWeaponsPlugin
{
    // All state and callbacks run on the game thread. There is no tick listener or
    // repeating timer here; at most one queued check and one redeploy per session.
    private sealed class HeldCheck(uint pawn, int map)
    {
        public readonly uint Pawn = pawn;
        public readonly int Map = map;
        public bool Force;
        public long PickedDefinition;
        public string? ChangedCategory;
    }
    private sealed class HeldRefresh(Session session, uint pawn, uint weapon, int map,
        uint alternate, string targetCommand)
    {
        public readonly Session Session = session;
        public readonly uint Pawn = pawn;
        public readonly uint Weapon = weapon;
        public readonly int Map = map;
        public readonly uint Alternate = alternate;
        public readonly string TargetCommand = targetCommand;
    }
    private readonly Dictionary<uint, HeldRefresh> _heldRefreshes = [];

    private static string? SlotCommand(gear_slot_t? slot) => slot switch
    {
        gear_slot_t.GEAR_SLOT_RIFLE => "slot1",
        gear_slot_t.GEAR_SLOT_PISTOL => "slot2",
        gear_slot_t.GEAR_SLOT_KNIFE => "slot3",
        _ => null
    };
    private static string? ReadModel(CBaseModelEntity weapon) =>
        weapon.CBodyComponent?.SceneNode?.GetSkeletonInstance()?.ModelState.ModelName;

    private void QueueHeldCheck(CCSPlayerController? player, bool force = false, long pickedDefinition = 0, string? changedCategory = null)
    {
        var session = EnsureSession(player);
        if (session == null || player == null || !player.PawnIsAlive) return;
        // Pickup can precede ActiveWeapon changing. Forget the matching cached
        // definition now so a later equip also refreshes a previously seen item.
        if (pickedDefinition != 0)
            foreach (var (handle, seen) in session.HeldModels)
                if (seen.Definition == pickedDefinition) session.HeldModels.Remove(handle);
        var pawn = player.PlayerPawn.Raw;
        if (session.HeldCheck is {} pending && pending.Pawn == pawn && pending.Map == _mapGeneration)
        {
            pending.Force |= force;
            if (pickedDefinition != 0) pending.PickedDefinition = pickedDefinition;
            if (changedCategory != null) pending.ChangedCategory = changedCategory;
            return;
        }
        var check = new HeldCheck(pawn, _mapGeneration) { Force = force, PickedDefinition = pickedDefinition, ChangedCategory = changedCategory };
        session.HeldCheck = check;
        Server.NextFrame(() =>
        {
            if (!ReferenceEquals(session.HeldCheck, check)) return;
            session.HeldCheck = null;
            if (!ResolveHeldOwner(session, check.Pawn, check.Map, false, out var owner, out var services)) return;
            var active = services.ActiveWeapon.Value;
            if (active is not { IsValid: true } || active.OwnerEntity.Raw != check.Pawn) return;
            if (session.HeldRefresh is {} running)
            {
                // Ignore our own temporary holster/equip notifications. A model
                // changed again while pending is observed by the original return.
                if (active.EntityHandle.Raw == running.Weapon || active.EntityHandle.Raw == running.Alternate) return;
                CancelHeldRefresh(session, false, false);
            }
            var raw = active.EntityHandle.Raw;
            var forcedTarget = check.Force && check.ChangedCategory != null &&
                WeaponNames.Resolve(active.DesignerName, active.AttributeManager.Item.ItemDefinitionIndex, Config.Weapons.Keys) == check.ChangedCategory;
            if (!_applied.ContainsKey(raw) && !forcedTarget && !session.HeldModels.ContainsKey(raw)) return;
            var data = active.As<CCSWeaponBase>().VData;
            var command = SlotCommand(data?.GearSlot);
            if (command == null) return; // Never cycle grenades/throwing weapons.
            var model = ReadModel(active);
            if (string.IsNullOrWhiteSpace(model)) return;
            var pickup = check.PickedDefinition != 0 && check.PickedDefinition == active.AttributeManager.Item.ItemDefinitionIndex;
            if (!pickup && session.HeldModels.TryGetValue(raw, out var seen) && seen.Pawn == check.Pawn && seen.Model == model) return;

            CBasePlayerWeapon? alternate = null;
            string? alternateCommand = null;
            var sameSlot = 0;
            Span<int> slotCounts = stackalloc int[3];
            slotCounts.Clear();
            // A slot command must identify the target unambiguously. Do not
            // remove, create or rearrange inventory to manufacture an alternate.
            foreach (var handle in services.MyWeapons)
            {
                var weapon = handle.Value;
                if (weapon is not { IsValid: true } || weapon.OwnerEntity.Raw != check.Pawn) continue;
                var slot = weapon.As<CCSWeaponBase>().VData?.GearSlot;
                if (slot == data!.GearSlot) { sameSlot++; continue; }
                var slotCommand = SlotCommand(slot);
                if (slotCommand == null) continue;
                slotCounts[slotCommand == "slot1" ? 0 : slotCommand == "slot2" ? 1 : 2]++;
                if (alternate == null || weapon.EntityHandle.Raw == services.LastWeapon.Raw)
                { alternate = weapon; alternateCommand = slotCommand; }
            }
            if (sameSlot != 1 || alternate == null || alternateCommand == null) return;
            if (slotCounts[alternateCommand == "slot1" ? 0 : alternateCommand == "slot2" ? 1 : 2] != 1) return;
            var request = new HeldRefresh(session, check.Pawn, raw, check.Map, alternate.EntityHandle.Raw, command);
            session.HeldRefresh = request;
            _heldRefreshes[raw] = request;
            try
            {
                owner.ExecuteClientCommand(alternateCommand);
                // One bounded delayed return gives the client a deploy boundary.
                // Unlike a repeating timer this callback owns no idle work.
                Server.RunOnTick(Server.TickCount + 8, () => ReturnHeldWeapon(request));
            }
            catch (Exception ex)
            {
                CancelHeldRefresh(session, true);
                Logger.LogWarning("Held model redeploy failed ({Type}).", ex.GetType().Name);
            }
        });
    }

    private bool ResolveHeldOwner(Session session, uint pawn, int map, bool cleanup,
        out CCSPlayerController player, out CPlayer_WeaponServices services)
    {
        player = null!; services = null!;
        if ((!cleanup && (!_active || _lifecycle?.MapReady != true)) || map != _mapGeneration) return false;
        var current = new CHandle<CCSPlayerController>(session.Controller).Value;
        if (current is not { IsValid: true } || !current.PawnIsAlive || current.PlayerPawn.Raw != pawn ||
            !_sessions.TryGetValue(current.Slot, out var live) || !ReferenceEquals(live, session)) return false;
        var currentPawn = current.PlayerPawn.Value;
        if (currentPawn is not { IsValid: true } || currentPawn.WeaponServices is not {} weaponServices) return false;
        player = current; services = weaponServices;
        return true;
    }

    private void ReturnHeldWeapon(HeldRefresh request)
    {
        if (!ReferenceEquals(request.Session.HeldRefresh, request)) return;
        try
        {
            if (!ResolveHeldOwner(request.Session, request.Pawn, request.Map, false, out var player, out var services)) return;
            var weapon = new CHandle<CBasePlayerWeapon>(request.Weapon).Value;
            if (weapon is not { IsValid: true } || weapon.OwnerEntity.Raw != request.Pawn) return;
            var active = services.ActiveWeapon.Raw;
            // A blocked switch did not create a deploy boundary. Do not cache it
            // as refreshed, or override a later manual selection.
            if (active != request.Alternate || !UniqueTarget(services, request)) return;
            player.ExecuteClientCommand(request.TargetCommand);
            RememberHeldModel(request.Session, request.Pawn, weapon, ReadModel(weapon));
        }
        catch (Exception ex) { Logger.LogWarning("Held model return failed ({Type}).", ex.GetType().Name); }
        finally { RemoveHeldRefresh(request); }
    }

    private static void RememberHeldModel(Session session, uint pawn, CBasePlayerWeapon weapon, string? model)
    {
        var raw = weapon.EntityHandle.Raw;
        if (session.HeldModels.Count >= 64 && !session.HeldModels.ContainsKey(raw)) session.HeldModels.Clear();
        session.HeldModels[raw] = (pawn, model, weapon.AttributeManager.Item.ItemDefinitionIndex);
    }

    private static bool UniqueTarget(CPlayer_WeaponServices services, HeldRefresh request)
    {
        var count = 0;
        foreach (var handle in services.MyWeapons)
            if (handle.Value is { IsValid: true } weapon && weapon.OwnerEntity.Raw == request.Pawn &&
                SlotCommand(weapon.As<CCSWeaponBase>().VData?.GearSlot) == request.TargetCommand)
            {
                if (weapon.EntityHandle.Raw != request.Weapon || ++count > 1) return false;
            }
        return count == 1;
    }

    private void RemoveHeldRefresh(HeldRefresh request)
    {
        if (ReferenceEquals(request.Session.HeldRefresh, request)) request.Session.HeldRefresh = null;
        if (_heldRefreshes.TryGetValue(request.Weapon, out var current) && ReferenceEquals(current, request)) _heldRefreshes.Remove(request.Weapon);
    }
    private void CancelHeldRefresh(Session session, bool restoreSelection, bool clearSeen = true)
    {
        session.HeldCheck = null;
        if (session.HeldRefresh is {} request)
        {
            try
            {
                if (restoreSelection && ResolveHeldOwner(session, request.Pawn, request.Map, true, out var player, out var services) &&
                    (services.ActiveWeapon.Raw == request.Alternate || services.ActiveWeapon.Raw == request.Weapon) &&
                    UniqueTarget(services, request) &&
                    new CHandle<CBasePlayerWeapon>(request.Weapon).Value is { IsValid: true } weapon && weapon.OwnerEntity.Raw == request.Pawn)
                    player.ExecuteClientCommand(request.TargetCommand);
            }
            catch (Exception ex) { Logger.LogWarning("Held model cleanup failed ({Type}).", ex.GetType().Name); }
            RemoveHeldRefresh(request);
        }
        if (clearSeen) session.HeldModels.Clear();
    }
    private void ClearHeldRefreshes(bool restoreSelection)
    {
        foreach (var session in _sessions.Values) CancelHeldRefresh(session, restoreSelection);
        _heldRefreshes.Clear();
    }
}
