#if HELD_REFRESH
using System.Collections;
using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CustomWeapons;

internal static partial class Program
{
    private static (CCSPlayerController Player, Weapon Target, Weapon Alternate) Armed(int slot)
    {
        var player = Player(slot);
        Give(player, "weapon_knife");
        var pistol = Give(player, "weapon_glock");
        var ak = Give(player, "weapon_ak47");
        ak.AttributeManager.Item.ItemDefinitionIndex = 7;
        player.PlayerPawn.Value!.WeaponServices!.LastWeapon = new(pistol.EntityHandle.Raw);
        return (player, ak, pistol);
    }
    private static int Pending(CustomWeaponsPlugin plugin) => ((IDictionary)Get(plugin, "_heldRefreshes")!).Count;
    private static object Session(CustomWeaponsPlugin plugin, int slot) => ((IDictionary)Get(plugin, "_sessions")!)[slot]!;
    private static IDictionary Seen(CustomWeaponsPlugin plugin, int slot) =>
        (IDictionary)Session(plugin, slot).GetType().GetProperty("HeldModels")!.GetValue(Session(plugin, slot))!;
    private static void Equip(CustomWeaponsPlugin plugin, CCSPlayerController player) => plugin.Fire(new EventItemEquip { Userid = player });
    private static void Select(CustomWeaponsPlugin plugin, CCSPlayerController player, string? id) => Call(plugin, "Select", player, "weapon_ak47", id);

    private static async Task HeldRefreshTests()
    {
        {
            var plugin = await Start(false); plugin.Config.CooldownSeconds = 0;
            var (player, ak, pistol) = Armed(1);
            var services = player.PlayerPawn.Value!.WeaponServices!;
            Select(plugin, player, null); Server.DrainFrames(); Server.AdvanceTicks(8);
            player.ClientCommands.Clear();
            ak.Clip1 = 13; ak.ReserveAmmo[0] = 47; ak.AttributeManager.Item.ItemID = 987654321;
            ak.AttributeManager.Item.CustomName = "retained item";
            var raw = ak.EntityHandle.Raw; var entityCount = Entities.All.Count;
            Select(plugin, player, "gun");
            Check(ak.Model == "models/gun.vmdl" && player.ClientCommands.Count == 0, "Selection changes model before delayed redeploy");
            Server.DrainFrames();
            Check(player.ClientCommands.SequenceEqual(["slot2"]) && services.ActiveWeapon.Raw == pistol.EntityHandle.Raw, "Prefer existing last weapon for holster");
            Check(Pending(plugin) == 1 && Server.Ticks.Sum(t => t.Value.Count) == 1, "Only one delayed return");
            Server.AdvanceTicks(7); Check(player.ClientCommands.Count == 1, "Return waits for deploy boundary");
            Server.AdvanceTicks(1);
            Check(player.ClientCommands.SequenceEqual(["slot2", "slot1"]) && services.ActiveWeapon.Raw == raw, "Return to exact existing target");
            Check(Entities.All.Count == entityCount && services.MyWeapons.Count == 3 && ak.EntityHandle.Raw == raw && ak.IsValid,
                "No replacement, deletion, duplicate or inventory reorder");
            Check(ak.Clip1 == 13 && ak.ReserveAmmo[0] == 47 && ak.AttributeManager.Item.ItemID == 987654321 &&
                ak.AttributeManager.Item.CustomName == "retained item", "Ammo and item identity stay untouched");
            Check(Pending(plugin) == 0 && Seen(plugin, 1).Count == 1, "Completed work becomes bounded cache entry");
            Weapon.DefinitionReads = 0; Utilities.PlayerScans = 0; var commands = player.ClientCommands.Count;
            for (var i = 0; i < 1000; i++) { Equip(plugin, player); Server.DrainFrames(); }
            Check(Weapon.DefinitionReads == 0 && Utilities.PlayerScans == 0 && player.ClientCommands.Count == commands && Server.Ticks.Count == 0,
                "Unchanged equip events do no inventory/application/definition work and queue no returns");
            Select(plugin, player, "gun"); Server.DrainFrames();
            Check(player.ClientCommands.Count == commands, "Repeated selection of same model does not cycle");
            Select(plugin, player, null); Server.DrainFrames(); Server.AdvanceTicks(8);
            Check(ak.Model == "models/stock.vmdl" && player.ClientCommands.Count == commands + 2, "Stock reversion also redeploys existing entity");
            plugin.Unload(false);
        }

        {
            var plugin = await Start(false);
            var (player, ak, pistol) = Armed(1); Safety(plugin)(); Equip(plugin, player);
            Server.DrainFrames(); Server.AdvanceTicks(8); player.ClientCommands.Clear();
            var services = player.PlayerPawn.Value!.WeaponServices!;
            // Pickup arrives while a different item is active. Later equip must
            // still refresh the same previously cached instance.
            services.ActiveWeapon = new(pistol.EntityHandle.Raw);
            plugin.Fire(new EventItemPickup { Userid = player, Defindex = 7 }); Server.DrainFrames();
            Check(player.ClientCommands.Count == 0 && Seen(plugin, 1).Count == 0, "Pickup invalidates matching cache before active handle changes");
            services.ActiveWeapon = new(ak.EntityHandle.Raw); Equip(plugin, player); Server.DrainFrames(); Server.AdvanceTicks(8);
            Check(player.ClientCommands.Count == 2 && services.ActiveWeapon.Raw == ak.EntityHandle.Raw, "Later equip after pickup refreshes same handle");
            plugin.Fire(new EventItemPickup { Userid = player, Defindex = 7 }); Server.DrainFrames(); Server.AdvanceTicks(8);
            Check(player.ClientCommands.Count == 4, "Immediate same-handle pickup refreshes too");
            plugin.Unload(false);
        }

        foreach (var invalidation in new[] { "death", "spawn", "disconnect", "replacement-session", "pawn", "map", "delete", "drop", "transfer", "manual", "ambiguous-return" })
        {
            var plugin = await Start(false);
            var (player, ak, _) = Armed(1); Safety(plugin)(); Equip(plugin, player); Server.DrainFrames();
            Check(Pending(plugin) == 1, "Prepared delayed return: " + invalidation);
            var services = player.PlayerPawn.Value!.WeaponServices!;
            switch (invalidation)
            {
                case "death": player.PawnIsAlive = false; plugin.Fire(new EventPlayerDeath { Userid = player }); break;
                case "spawn": plugin.Fire(new EventPlayerSpawn { Userid = player }); break;
                case "disconnect": Disconnect(plugin, 1); Utilities.Players.Remove(player); Armed(1); break;
                case "replacement-session":
                    Utilities.Players.Remove(player); var next = Armed(1); Equip(plugin, next.Player); break;
                case "pawn": player.PlayerPawn = new(new Pawn().EntityHandle.Raw); break;
                case "map": MapEnd(plugin); break;
                case "delete":
                    ((Listeners.OnEntityDeleted)plugin.ListenersByType[typeof(Listeners.OnEntityDeleted)])(ak); ak.IsValid = false; break;
                case "drop": ak.OwnerEntity = new(0); services.MyWeapons.RemoveAll(h => h.Raw == ak.EntityHandle.Raw); break;
                case "transfer": ak.OwnerEntity = new(Player(2).PlayerPawn.Raw); break;
                case "manual":
                    services.ActiveWeapon = new(services.MyWeapons[0].Raw); Equip(plugin, player); break;
                case "ambiguous-return":
                    Give(player, "weapon_awp"); services.ActiveWeapon = new(services.MyWeapons[1].Raw); break;
            }
            Server.DrainFrames(); Server.AdvanceTicks(8);
            Check(player.ClientCommands.SequenceEqual(["slot2"]) && Pending(plugin) == 0, "Stale return cannot change selection: " + invalidation);
            plugin.Unload(false);
        }

        foreach (var invalidation in new[] { "death", "disconnect", "map", "unload" })
        {
            var plugin = await Start(false); var (player, _, _) = Armed(1); Safety(plugin)(); Equip(plugin, player);
            switch (invalidation)
            {
                case "death": player.PawnIsAlive = false; plugin.Fire(new EventPlayerDeath { Userid = player }); break;
                case "disconnect": Disconnect(plugin, 1); break;
                case "map": MapEnd(plugin); break;
                case "unload": plugin.Unload(false); break;
            }
            Server.DrainFrames(); Server.AdvanceTicks(8);
            Check(player.ClientCommands.Count == 0 && Pending(plugin) == 0, "Cancel before next frame: " + invalidation);
            if (invalidation != "unload") plugin.Unload(false);
        }

        {
            var plugin = await Start(false); var (player, ak, _) = Armed(1); Safety(plugin)(); Equip(plugin, player); Server.DrainFrames();
            plugin.Unload(false); Server.AdvanceTicks(8);
            Check(player.ClientCommands.SequenceEqual(["slot2", "slot1"]) && Pending(plugin) == 0 && ak.Model == "models/stock.vmdl",
                "Unload restores selection/model and cancels scheduled return");
        }

        foreach (var unsafeInventory in new[] { "only-target", "duplicate-target-slot", "duplicate-alternate-slot", "grenade-active", "blocked-command" })
        {
            var plugin = await Start(); var (player, ak, _) = Armed(1);
            var services = player.PlayerPawn.Value!.WeaponServices!;
            if (unsafeInventory == "only-target") services.MyWeapons.RemoveAll(h => h.Raw != ak.EntityHandle.Raw);
            if (unsafeInventory == "duplicate-target-slot") { Give(player, "weapon_awp"); services.ActiveWeapon = new(ak.EntityHandle.Raw); }
            if (unsafeInventory == "duplicate-alternate-slot") { Give(player, "weapon_deagle"); services.ActiveWeapon = new(ak.EntityHandle.Raw); }
            if (unsafeInventory == "grenade-active") Give(player, "weapon_flashbang");
            if (unsafeInventory == "blocked-command") player.ClientSwitchEnabled = false;
            Safety(plugin)(); Equip(plugin, player); Server.DrainFrames(); Server.AdvanceTicks(8);
            Check(player.ClientCommands.Count == (unsafeInventory == "blocked-command" ? 1 : 0) && Pending(plugin) == 0 && Seen(plugin, 1).Count == 0,
                "Do not guess, replace or cache failed deployment: " + unsafeInventory);
            plugin.Unload(false);
        }

        {
            var plugin = await Start(false); plugin.Config.CooldownSeconds = 0;
            var (player, ak, pistol) = Armed(1); var services = player.PlayerPawn.Value!.WeaponServices!;
            services.ActiveWeapon = new(pistol.EntityHandle.Raw); Select(plugin, player, "gun"); Server.DrainFrames();
            Check(player.ClientCommands.Count == 0 && ak.Model == "models/gun.vmdl", "Changing inactive category does not interrupt active pistol");
            services.ActiveWeapon = new(ak.EntityHandle.Raw); Equip(plugin, player); Server.DrainFrames(); Server.AdvanceTicks(8);
            Check(player.ClientCommands.Count == 2, "Changed inactive model refreshes on next equip");
            services.ActiveWeapon = new(pistol.EntityHandle.Raw); Select(plugin, player, null); Server.DrainFrames();
            Check(player.ClientCommands.Count == 2 && ak.Model == "models/stock.vmdl", "Inactive stock reversion does not interrupt pistol");
            services.ActiveWeapon = new(ak.EntityHandle.Raw); Equip(plugin, player); Server.DrainFrames(); Server.AdvanceTicks(8);
            Check(player.ClientCommands.Count == 4, "Inactive stock reversion refreshes on next equip without _applied entry");
            plugin.Unload(false);
        }

        foreach (var count in new[] { 0, 1, 8, 32 })
        {
            var plugin = await Start(false); var players = Enumerable.Range(0, count).Select(i => Armed(i).Player).ToArray();
            Safety(plugin)(); Utilities.PlayerScans = 0;
            foreach (var player in players) for (var i = 0; i < 100; i++) Equip(plugin, player);
            Check(Server.Frames.Count == count, "Burst coalesces to one check per session: " + count);
            Server.DrainFrames();
            Check(Pending(plugin) == count && Server.Ticks.Sum(t => t.Value.Count) == count, "Bounded pending returns: " + count);
            Server.AdvanceTicks(8);
            Check(Pending(plugin) == 0 && Server.Ticks.Count == 0 && Utilities.PlayerScans == 0 && players.All(p => p.ClientCommands.Count == 2),
                "Event work settles without global player scans: " + count);
            Check(plugin.Timers.Count == 2 && !plugin.ListenersByType.ContainsKey(typeof(Listeners.OnTick)), "No new timer or gun-only tick work: " + count);
            plugin.Unload(false);
        }
    }
}
#endif
